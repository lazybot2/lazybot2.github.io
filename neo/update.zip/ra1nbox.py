# -----------------------------
# Copyright Ra1nbox
# Author: https://ra1nbox.com
# License: Do not redistribute and/or sell without written consent. For more info, see the website
# The software is provided without warranty of any kind
# -----------------------------
import subprocess
import time
import signal
import os
import sys
from types import SimpleNamespace

import sh
import distutils.core
import urllib.request
import shutil

# Import Python Imaging Library
from PIL import Image, ImageDraw, ImageFont

HAS_LIBIMOBILE = shutil.which("idevice_id") is not None

DEBUG = os.getenv("DEBUG", None) is not None
if DEBUG:
    ROOTDIR = "."
else:
    ROOTDIR = "/home/ra1nbox/ra1nbox"

try:
    # Import OLED library
    import bakebit_128_64_oled as display

    # Prepare display
    display.init()  # initialze SEEED OLED display
    
    display.clearDisplay()  # Clear the screen and set start position to top left corner
    display.setNormalDisplay()  # Set display to normal mode (i.e non-inverse mode)
    display.setHorizontalMode()

    # Simple wrapper to debug on host machine
    def drawImage (image):
        return display.drawImage(image)
    
    def clearDisplay ():
        return display.clearDisplay()
except:
    if not DEBUG:
        raise
    def drawImage (image):
        print("Draw image!")
        return None
    
    def clearDisplay ():
        print("Clear image!")
        return None

# Print default message
print('Ctrl + C to quit')

# Show boot logo
image = Image.open(ROOTDIR + '/logo.ppm').convert('1')
drawImage(image)
time.sleep(3)  # seconds to show boot logo

# Create blank image for drawing.
width = 128
height = 64
image = Image.new('1', (width, height))

# Get drawing object to draw on image.
draw = ImageDraw.Draw(image)

# Load fonts
font = ImageFont.load_default()
font2 = ImageFont.truetype('DejaVuSansMono.ttf', 9)
font3 = ImageFont.truetype('DejaVuSansMono.ttf', 11)

ra1nbox_version = ''
# Load default settings from file
def load_ra1nbox_version():
    global ra1nbox_version

    with open('version.conf', 'r') as versionFile:
        ra1nbox_version = versionFile.read()

class ScreenDraw(object):
    def __init__(self, draw, image):
        self.draw = draw
        self.image = image

    def button_f1(self, text):
        self.draw.rectangle((-1, 53, 42, 53 + 12), outline=255, fill=0)
        f1text = text
        w, h = self.draw.textsize(f1text)
        self.draw.text(((42 - w) / 2 + 2, 53), f1text, fill=255)

    def button_f2(self, text):
        self.draw.rectangle((43, 53, 84, 53 + 12), outline=255, fill=0)
        f1text = text
        w, h = self.draw.textsize(f1text)
        self.draw.text(((42 - w) / 2 + 44, 53), f1text, fill=255)

    def button_f3(self, text):
        self.draw.rectangle((85, 53, 128, 53 + 12), outline=255, fill=0)
        f1text = text
        w, h = self.draw.textsize(f1text)
        self.draw.text(((42 - w) / 2 + 86, 53), f1text, fill=255)

    def drawTextLine(self, text, ln=None, off=None, font=None):
        if off is None:
            off = top + ln * 10
        if font:
            kwargs = {"font": font}
        else:
            kwargs = {}
        w, h = draw.textsize(text, **kwargs)
        self.drawText(text, ((width - w) / 2, off), font)
        
    def drawText(self, text, pos, font=None):
        if font:
            kwargs = {"font": font}
        else:
            kwargs = {}
        draw.text(pos, text, fill=255, **kwargs)
    
    def drawOptionLine(self, option_text, highlight, ln):
        off = ln * 18 + top
        draw.rectangle((2, off, width - 4, off + 14), outline=0, fill=255 if highlight else 0)
        draw.text((10, off + 1), option_text, fill=0 if highlight else 255)
    
    def commit(self):
        display.drawImage(self.image)
    
    def clear(self):
        draw.rectangle((0, 0, width, height), outline=0, fill=0)

painter = ScreenDraw(draw, image)

if not HAS_LIBIMOBILE:
    painter.drawTextLine("Updating dependencies", off=2)
    painter.commit()
    def update():
        try:
            subprocess.call(["dpkg", "--configure", "-a"])
            subprocess.call(["apt-get", "install", "-f", "-y"])

            painter.drawTextLine("Doing apt update...", off=20)
            painter.commit()
            ret = subprocess.call(["apt-get", "update"])
            if ret:
                painter.drawTextLine("apt update failed!", off=30)
                painter.commit()
                return

            painter.drawTextLine("Doing apt install...", off=30)
            painter.commit()
            ret = subprocess.call(["apt-get", "install", "-y", "usbmuxd", "libimobiledevice-utils"])
            if ret:
                painter.drawTextLine("apt install failed!", off=40)
                painter.commit()
                return
            #ret = subprocess.call("pip3 install -U sh")
            painter.drawTextLine("Update success!", off=45)
            painter.commit()

            # Reboot in order to apply changes for HAS_LIBIMOBILE
            time.sleep(1)

            clearDisplay()
            os.system('systemctl reboot')
            sys.exit(0)

        except:
            import traceback; traceback.print_exc()
            painter.drawTextLine("Unknown fail :(", off=45)
            painter.commit()
            return
    update()
    painter.commit()
    time.sleep(3)

class Ra1nBoxSettings(object):
    def __init__(self):
        self.setting_verbose = None
        self.setting_safemode = None
        self.setting_autoshutdown = None
        self.load_default_settings()

    # Load default settings from file
    def load_default_settings(self):
        with open('settings.conf', 'r') as settingsFile:
            lines = [line.rstrip() for line in settingsFile]
            for line in lines:
                settingContent = line.split('=')

                if settingContent[0] == 'setting_verbose':
                    self.setting_verbose = bool(distutils.util.strtobool(settingContent[1]))
                elif settingContent[0] == 'setting_safemode':
                    self.setting_safemode = bool(distutils.util.strtobool(settingContent[1]))
                elif settingContent[0] == 'setting_autoshutdown':
                    self.setting_autoshutdown = bool(distutils.util.strtobool(settingContent[1]))

    # Load setting
    def load_setting(self, setting):
        if (setting == 'verbose'):
            if (self.setting_verbose == True):
                return '[X]'
            else:
                return '[ ]'
        elif (setting == 'safemode'):
            if (self.setting_safemode == True):
                return '[X]'
            else:
                return '[ ]'
        elif (setting == 'autoshutdown'):
            if (self.setting_autoshutdown == True):
                return '[X]'
            else:
                return '[ ]'

    # Save setting
    def save_setting(self, setting):
        # Prepare settings file
        with open('settings.conf', 'w') as settingsFile:
            if (setting == 'verbose'):
                if (self.setting_verbose == False):
                    self.setting_verbose = True
                else:
                    self.setting_verbose = False
            elif (setting == 'safemode'):
                if (self.setting_safemode == False):
                    self.setting_safemode = True
                else:
                    self.setting_safemode = False
            elif (setting == 'autoshutdown'):
                if (self.setting_autoshutdown == False):
                    self.setting_autoshutdown = True
                else:
                    self.setting_autoshutdown = False

            # Save settings
            settingsFile.write('\n'.join(
                ['setting_verbose=' + str(self.setting_verbose), 'setting_safemode=' + str(self.setting_safemode),
                 'setting_autoshutdown=' + str(self.setting_autoshutdown)]))

def get_device_state():
    appledevice = subprocess.check_output('lsusb | grep "Apple"; exit 0', shell=True)
    # --- Check if Apple device connected ---
    if not appledevice:
        return None

    # check if DFU or recovery mode present
    devicerecovery = subprocess.check_output('lsusb | grep "Recovery"; exit 0', shell=True)
    devicedfu = subprocess.check_output('lsusb | grep "DFU"; exit 0', shell=True)

    return "dfu" if devicedfu else \
        "recovery" if devicerecovery else "normal"


top = 2

class Ra1nBox(object):
    def __init__(self):
        # Prepare page indexing
        self.pageIndex = 'home'  # Set first page to load
        self.lastPageIndex = self.pageIndex
        self.connected = False
        self.connectedState = None
        self.lastConnectedState = self.connectedState
        if DEBUG:
            self.pageIndex = DEBUG
        
        # Load default settings from file
        self.settings = Ra1nBoxSettings()

        self.checkrain_status = 'killed'
        self.checkrain_kill = 0
        self.process = None

        # look for button press
        signal.signal(signal.SIGUSR1, self.receive_signal)
        signal.signal(signal.SIGUSR2, self.receive_signal)
        signal.signal(signal.SIGALRM, self.receive_signal)

    F1 = signal.SIGUSR1
    F2 = signal.SIGUSR2
    F3 = signal.SIGALRM

    state_map = {
        "home": {
            F2: 'options-verbose',
            F3: 'exit-no',
        },
        "systeminfo": {
            F3: 'options-systeminfo'
        },
        'updates': {
            F3: 'options-checkforupdates'
        },
        'updates-confirmation': {
            F1: 'updates-updating',
            F3: 'options-checkforupdates',
        },
        'exit-no': {
            F1: 'exit-yes',
            F2: 'exit-yes',
            F3: 'home'
        },
        'exit-yes': {
            F1: 'exit-no',
            F2: 'exit-no',
            F3: 'exit-exit'
        },
        'checkra1n': {},
        None: {
            F1: 'home',
            F2: 'home',
            F3: 'exit-no',
        }
    }

    def handle_option_signal(self, signum):
        options = ["verbose", "safemode", "autoshutdown", "systeminfo", "checkforupdates", "back"]
        cur = options.index(self.pageIndex[len("options-"):])
        if signum == self.F1:
            self.pageIndex = "options-" + options[(cur - 1 + len(options)) % len(options)]
        elif signum == self.F2:
            self.pageIndex = "options-" + options[(cur + 1) % len(options)]
        elif signum == self.F3:
            if options[cur] in ("verbose", "safemode", "autoshutdown"):
                self.settings.save_setting(options[cur])
            elif self.pageIndex == 'options-systeminfo':
                self.pageIndex = 'systeminfo'
            elif self.pageIndex == 'options-checkforupdates':
                self.pageIndex = 'updates'
            elif self.pageIndex == 'options-back':
                self.pageIndex = 'home'
            # force refresh
            self.lastPageIndex = None

    # Define button layout mapping
    def receive_signal(self, signum, stack):
        # Make buttons better readable
        print("Received signal %s, connected: %s cur pageIndex: %s connState: %s lastConn: %s" %
              ({signal.SIGUSR1: "F1", signal.SIGUSR2: "F2", signal.SIGALRM: "F3"}[signum],
              self.connected, self.pageIndex, self.connectedState, self.lastConnectedState)
            )

        if not self.connected:
            # --- Load options page ---
            if self.pageIndex.startswith('options'):
                self.handle_option_signal(signum)
            else:
                action = self.state_map.get(self.pageIndex, None)
                if action is None:
                    action = self.state_map[None]
                if signum in action:
                    self.pageIndex = action[signum]
        else:
            if self.connectedState is None:
                pass
            elif self.connectedState == 'normal-prepare':
                if signum == self.F3:
                    self.connectedState = 'normal-switching'
            elif self.connectedState == 'recovery-prepare':
                if signum == self.F3:
                    self.connectedState = 'recovery-switching'
            elif self.connectedState == 'dfu-prepare':
                if signum == self.F3:
                    self.connectedState = 'dfu-switching'

        # When checkra1n's executing, it can be both connected or disconnected
        if self.pageIndex == 'checkra1n':
            if signum == self.F3:
                # Force quit checkra1n if F3 is pressed 3x while checkra1n is running
                print('Kill request received ' + str(self.checkrain_kill))
                self.checkrain_kill += 1
                if self.checkrain_status == 'running' and self.checkrain_kill > 2:
                    self.checkrain_status = 'killed'
                    self.pageIndex = 'exit-yes'
                    self.process.kill()
                    clearDisplay()
                    os.system('systemctl reboot')
                    sys.exit(0)

        time.sleep(0.005)

    def draw_home(self,
                    l=SimpleNamespace(connectx=22, connectx_dir="LTR") # function static vars
                    ):
        # Show button options
        painter.button_f2('Opt')
        painter.button_f3('Exit')

        # Welcome message
        painter.drawTextLine("Welcome to Ra1nbox", 0)
        painter.drawTextLine("Make it ra1n:", 2)

        # Animate text
        if l.connectx < 40 and l.connectx_dir == "LTR":
            l.connectx += 5
        else:
            l.connectx -= 5
            l.connectx_dir = "RTL"

            if l.connectx < 6:
                l.connectx_dir = "LTR"

        # Show animated connect text
        painter.drawText("Connect device", (l.connectx, 30))
    
    def draw_options(self):
        painter.button_f1('UP')
        painter.button_f2('DOWN')
        painter.button_f3('OK')
        
        options = ("verbose", "safemode", "autoshutdown", "systeminfo", "checkforupdates", "back")
        cur = options.index(self.pageIndex[len("options-"):])
        for j in range(3):
            i = j + cur
            if j >= len(options):
                break
            
            if i == 0:
                painter.drawOptionLine('Verbose mode ' + self.settings.load_setting('verbose'), j == 0, j)
            elif i == 1:
                painter.drawOptionLine('Safe mode ' + self.settings.load_setting('safemode'), j == 0, j)
            elif i == 2:
                painter.drawOptionLine('Auto shutdown ' + self.settings.load_setting('autoshutdown'), j == 0, j)
            elif i == 3:
                painter.drawOptionLine('System info', j == 0, j)
            elif i == 4:
                painter.drawOptionLine('Check for updates', j == 0, j)
            elif i == 5:
                painter.drawOptionLine('< Back', j == 0, j)
            else:
                pass
    
    def draw_systeminfo(self,
                          l=SimpleNamespace(version1='', version2='') # function static vars
                        ):
        painter.button_f3('< BACK')

        # Only check ra1nbox version if needed
        if ra1nbox_version == '':
            load_ra1nbox_version()
        
        painter.drawTextLine('Ra1nbox version ' + ra1nbox_version, None, 0)

        # Get Checkra1n version
        try:
            i = [0]

            def checkra1n_version(line, stdin, newprocess):
                # debug
                # print(line)

                # Only show output on matching pattern
                pattern = ["# ", "#=", "#"]
                res = [ele for ele in pattern if (ele in line)]
                show_output = bool(res)

                # Show matching output
                if show_output == False:
                    line = line.strip()  # Strip newline

                    # Skip empty lines
                    if line != '':
                        i[0] += 1

                        # Add to version
                        if i[0] == 1:
                            l.version1 = line
                        else:
                            # Remove checksum
                            newline = line.split(' ')
                            l.version2 = newline[1] + ' ' + newline[2]

            # Only check Checkra1n version if needed
            if l.version1 == '':
                # Prepare Checkra1n
                process = sh.Command(ROOTDIR + '/checkra1n')

                # Set paramters and run Checkra1n
                newprocess = process("--version", _out=checkra1n_version, _err=checkra1n_version)
            
            painter.drawTextLine(l.version1, off=15, font=font2)
            painter.drawTextLine(l.version2, off=24, font=font2)
        except:
            import traceback
            traceback.print_exc()
            # Output Checkra1n rights error
            painter.drawTextLine('Checkra1n rights error!', off=15, font=font2)
            painter.drawTextLine('Please read FAQ on site', off=24, font=font2)

        # Load temp
        tempI = int(open('/sys/class/thermal/thermal_zone0/temp').read())
        if tempI > 1000:
            tempI = tempI / 1000
        tempVal = str(round(tempI, 1))

        # Load arch
        arch = subprocess.check_output('arch', shell=True)
        arch = str(arch.decode('UTF-8')).rstrip('\n ,')

        systemInfo = 'ARCH:' + arch + ' | TEMP:' + str(tempVal) + 'C'

        # Output system info
        painter.drawTextLine(systemInfo, off=38, font=font2)

        # Get IP
        cmd = "hostname -I | cut -d\' \' -f1"
        IP = subprocess.check_output(cmd, shell=True).decode("utf-8")
        if len(IP) < 2:
            IP = 'no network'

        # Output IP
        painter.drawText(IP, (8, 53), font=font2)
    
    def draw_update(self,
                      l=SimpleNamespace(ra1nbox_current_version='', changelog='') # function static vars
                      ):
        if self.pageIndex == 'updates':

            # Make sure there is a network connection
            cmd = "hostname -I | cut -d\' \' -f1"
            IP = subprocess.check_output(cmd, shell=True).decode("utf-8")

            # No network available -- stop loading
            if len(IP) < 2:
                painter.button_f3('< BACK')
                # No network connection found
                IP = 'No network'
                painter.drawTextLine(IP, 0)
                
            # Netwerk available -- load other options
            else:
                # Only check ra1nbox version if needed
                if ra1nbox_version == '':
                    load_ra1nbox_version()

                if l.ra1nbox_current_version == '':
                    # Try connection
                    try:
                        # Request current version
                        opener = urllib.request.build_opener()
                        opener.addheaders = [('User-agent', 'Ra1nbox/' + ra1nbox_version)]
                        urllib.request.install_opener(opener)
                        check = urllib.request.urlopen("https://updates.ra1nbox.com/currentversion32")

                        # Response OK
                        if check.getcode() == 200:

                            # Load latest version
                            l.ra1nbox_current_version = str(check.read().decode("utf-8"))

                        # Reponse failed
                        else:
                            # Output response failed
                            painter.drawTextLine("Response failed", off=2)
                            # Output reason
                            painter.drawTextLine(check.getcode(), off=10)
                            # Timeout before redirect
                            time.sleep(3)
                            self.pageIndex = 'home'

                    # Connection failed
                    except urllib.error.URLError as e:
                        # Output connection failed
                        painter.drawTextLine("Connection failed", off=2)
                        # Output reason
                        painter.drawTextLine(e.reason, off=10)
                        # Timeout before redirect
                        time.sleep(3)
                        self.pageIndex = 'home'

                # Check if current version is same as Ra1nbox version
                if ra1nbox_version != l.ra1nbox_current_version:

                    # Send to updates-confirmation screen
                    self.pageIndex = 'updates-confirmation'

                else:
                    painter.button_f3('< BACK')
                    # No update available message
                    painter.drawTextLine("No updates available", off=2)
                    painter.drawTextLine("Ra1nbox version " + ra1nbox_version, off=22)
                    painter.drawTextLine("is latest version", off=30)

        elif self.pageIndex == 'updates-confirmation':

            # Update available message
            painter.drawTextLine("Update available:", off=0)
            # Version difference
            painter.drawTextLine("---- " + ra1nbox_version + " > " + l.ra1nbox_current_version + " ----", off=8)
            
            ## Only check changelog if needed
            if l.changelog == '':
                
                # Request changelog
                opener = urllib.request.build_opener()
                opener.addheaders = [('User-agent', 'Ra1nbox/' + ra1nbox_version)]
                urllib.request.install_opener(opener)
                check = urllib.request.urlopen("https://updates.ra1nbox.com/changelog32")
    
                # Load changelog
                l.changelog = str(check.read().decode("utf-8"))
    
            # Output changelog
            lines = l.changelog.split("\n")

            # Set line start and prepare counter
            i = 20

            # Loop through changelog lines
            for line in lines:
                # Output lines to screen
                painter.drawTextLine(line, off=i)
                i += 8

            # Final confirmation
            painter.button_f1('YES')
            painter.button_f3('NO')
            painter.drawTextLine('--- Update now? ---', off=40)

        elif self.pageIndex == 'updates-updating':

            # Updating messages
            painter.drawTextLine("Updating", off=1)
            painter.drawTextLine("-- PLEASE WAIT --", off=14)
            painter.drawTextLine("Do NOT unplug the power", off=27)

            # Display image
            painter.commit()
            time.sleep(1)

            # Download update file
            urllib.request.urlretrieve("https://updates.ra1nbox.com/download32", ROOTDIR + "/update.zip")

            # Output done
            painter.drawTextLine("DONE", off=40)
            painter.drawTextLine("rebooting...", off=50)

            # Display image
            painter.commit()
            time.sleep(1)

            clearDisplay()
            os.system('systemctl reboot')
            sys.exit(0)
    
    def draw_exit(self):
        if self.pageIndex == 'exit-exit':
            # Shutdown message
            painter.drawTextLine("Shutting down", off=top)
            painter.drawTextLine("Please wait", off=top + 20)

            # Display image
            painter.commit()
            time.sleep(2)
            clearDisplay()
            time.sleep(1)
            os.system('systemctl poweroff')
            sys.exit(0)
        else:
            # Show button options
            painter.button_f1('UP')
            painter.button_f2('DOWN')
            painter.button_f3('OK')
            # Shutdown message
            painter.drawTextLine("Shutdown?", off=top)

            if self.pageIndex == 'exit-no':
                painter.drawOptionLine('Yes', False, 1)
                painter.drawOptionLine('No', True, 2)
            elif self.pageIndex == 'exit-yes':
                painter.drawOptionLine('Yes', True, 1)
                painter.drawOptionLine('No', False, 2)

    
    def handle_not_connected(self):
        painter.clear()
        self.connected = False

        lastPageIndex = self.pageIndex
        ret = True
        # --- Load homepage ---
        if self.pageIndex == 'home':
            self.draw_home()
        # --- Load exit page ---
        elif self.pageIndex.startswith('options'):
            self.draw_options()
            
        # --- Load systeminfo page ---
        elif self.pageIndex == 'systeminfo':
            self.draw_systeminfo()

        # --- Load updates page ---
        elif self.pageIndex.startswith('updates'):
            self.draw_update()
            
        # --- Load exit page ---
        elif self.pageIndex.startswith('exit'):
            self.draw_exit()
        else:
            ret = False

        self.lastPageIndex = lastPageIndex
        return True

    def draw_normal_connected(self):
        # Write all output data
        painter.drawTextLine("- normal mode -", off=top + 10)

        if HAS_LIBIMOBILE:
            if self.connectedState == "normal-prepare":
                painter.drawTextLine("press START to enter", off=top + 25)
                painter.drawTextLine("recovery mode", off=top + 35)
                painter.button_f3("START")
            elif self.connectedState == "normal-switching":
                painter.drawTextLine("starting", off=top + 25)
                painter.drawTextLine("recovery mode", off=top + 35)
                print(str(self.lastConnectedState))
                if self.lastConnectedState == "normal-prepare":
                    try:
                        ids = subprocess.check_output(["idevice_id", "-l"])
                        print(ids)
                        ids = ids.strip().splitlines()

                        # painter.drawTextLine("Got id %s" % ids[0][0:10].decode(), off=top + 50)

                        if len(ids) == 0:
                            raise Exception("failed to get udid")

                        painter.commit()
                        output = subprocess.check_output(["ideviceenterrecovery", ids[0]])
                        print(output)

                        for i in range(40):
                            if get_device_state() == "recovery":
                                break
                            time.sleep(0.5)
                        else:
                            raise Exception("failed to enter rec")

                        painter.drawTextLine("Entered Recovery!", off=top + 50)
                    except Exception as e:
                        import traceback
                        traceback.print_exc()
                        painter.drawTextLine("error: %s" % str(e)[0:15], off=top + 50)
                        painter.commit()
                        time.sleep(2.0)
                        return
        else:
            painter.drawTextLine("only manual DFU", off=top + 25)
            painter.drawTextLine("is supported", off=top + 35)

    def draw_recovery_connected(self):
        # Write all output data
        painter.drawTextLine("- recovery mode -", off=top + 10)
        bak_image = image.copy()

        if not HAS_LIBIMOBILE:
            painter.drawTextLine("only manually DFU", off=top + 25)
            painter.drawTextLine("is supported", off=top + 40)
            return

        try:
            if self.connectedState == "recovery-prepare":
                if self.lastConnectedState != "recovery-prepare":
                    painter.drawTextLine("Preparing recovery", off=top + 25)
                    painter.commit()
                    ret = subprocess.check_output(["./irecovery", "-c", "setenv auto-boot true"])
                    print(b"autoboot: " + ret)

                    ret = subprocess.check_output(["./irecovery", "-c", "saveenv"])
                    print(b"saveenv: " + ret)
                    time.sleep(0.3)

                image.paste(bak_image)
                painter.drawTextLine("be ready to press", off=top + 25)
                painter.drawTextLine("DFU button sequence!", off=top + 35)
                painter.button_f3("DFU")
                painter.commit()
            if self.connectedState == "recovery-switching":
                comm = None
                startTime = time.time()
                for i in range(5, 0, -1):
                    image.paste(bak_image)
                    painter.drawTextLine("DFU stage1 (%d)" % (i), off=top + 25)
                    painter.commit()
                    if i == 3:
                        comm = subprocess.Popen(["./irecovery", "-c", "reboot"], stdout=subprocess.PIPE)
                    if i == 1:
                        data = comm.communicate()[0]
                        print(data)
                        if comm.returncode != 0:
                            raise Exception("reboot from rec fail!")
                    while (time.time() - startTime) < 5.0 - i + 1:
                        time.sleep(0.1)

                startTime = time.time()
                for i in range(10, 0, -1):
                    image.paste(bak_image)
                    painter.drawTextLine("DFU stage2 (%d)" % (i), off=top + 25)
                    state = get_device_state()
                    if state is None:
                        while (time.time() - startTime) < 10.0 - i + 1:
                            time.sleep(0.1)
                    elif state == "dfu":
                        break
                    else:
                        print(state)
                        image.paste(bak_image)
                        painter.drawTextLine("Err: Device comes to %s" % (state), off=top + 25)
                        painter.commit()
                        time.sleep(2)
                        break

                    painter.commit()
        except Exception as e:
            import traceback
            traceback.print_exc()
            painter.drawTextLine("error: %s" % str(e)[0:15], off=top + 35)
            return


    def draw_dfu_connected(self):
        # Set self.pageIndex to checkra1n
        self.pageIndex = 'checkra1n'

        # Start with blank screen
        painter.clear()
        painter.commit()

        outputlines = []
        def draw_lines():
            if len(outputlines) > 6:  # if more than 6 lines, then we need a full screen refresh
                painter.clear()

            # Show Checkra1n output on screen
            start = max(len(outputlines) - 6, 0)  # if > 6 lines in buf, then the last 6, else from 0
            for i in range(6):
                if start + i >= len(outputlines):
                    break
                painter.drawText(outputlines[start + i], (1, top + 10 * i))

            # Display image
            painter.commit()

        def process_output(line, stdin, newprocess):
            # debug
            # print(line)

            # Update checkra1n process status
            self.checkrain_status = 'running'

            # Only show output on matching pattern
            pattern = [" [*]", " [!]"]
            res = [ele for ele in pattern if (ele in line)]
            show_output = bool(res)

            # Show matching output
            if show_output == True:
                line = line.strip(' - [*]: ')  # strip default prefix
                line = line.strip(' - [!]: ')  # strip error prefix
                line = line.rstrip()  # Strip newline
                outputlines.append(line)
                draw_lines()
                # time.sleep(1)

                if "All Done" in line:
                    newprocess.kill()
                    return True

        def done(cmd, success, exit_code):
            # Draw a black filled box to clear the image.
            painter.clear()
            clearDisplay()

            # Update checkra1n process status
            self.checkrain_status = 'killed'

            # Output done message
            painter.drawTextLine("-- Ra1nbox JB done --", off=top)
            painter.drawTextLine("You can now safely", off=25)
            painter.drawTextLine("unplug the cable", off=33)

            # Display image
            painter.commit()
            time.sleep(3)

        # Welcome message
        outputlines.append("Booting Checkra1n...")
        draw_lines()

        # Prepare to run Checkra1n
        try:

            # Reset checkra1n force quit counter
            self.checkrain_kill = 0

            # Prepare Checkra1n
            process = sh.Command(ROOTDIR + '/checkra1n')

            command_args = {"_out":process_output, "_err":process_output, "_done": done, "_bg": True}
            # Set paramters and run Checkra1n
            if self.settings.setting_verbose == True and self.settings.setting_safemode == True:
                print('Checkra1n starting with Verbose and Safemode enabled')
                self.process = process("-c", "-V", "-s", **command_args)
            elif self.settings.setting_verbose == True:
                print('Checkra1n starting with Verbose enabled')
                self.process = process("-c", "-V", **command_args)
            elif self.settings.setting_safemode == True:
                print('Checkra1n starting with Safemode enabled')
                self.process = process("-c", "-s", **command_args)
            else:
                print('Checkra1n starting with no options')
                self.process = process("-c", **command_args)
            self.process.wait()
        except:
            print('Checkra1n ended')
            kill = True
            if hasattr(self.process, "is_alive"):
                kill = False
                if self.process.is_alive():
                    print('Checkra1n still alive, kill it!')
                    kill = True
            if kill:
                try:
                    self.process.kill()
                except:
                    pass
                self.process = None

        # Check setting if we need to auto-shutdown or return to home
        if self.settings.setting_autoshutdown == True:
            self.pageIndex = 'exit-exit'
        else:
            self.pageIndex = 'home'

    def handle_connected(self):
        # --- Load default page ---

        # Try to find connected USB devices
        state = get_device_state()

        # --- Check if Apple device connected ---
        if not state:
            self.lastConnectedState = self.connectedState = None
            self.connected = False
            return False

        lastConnectedState = self.connectedState

        painter.clear()

        # Write all output data
        painter.drawTextLine("Apple device found", off=top)

        if self.connectedState is None or not self.connectedState.startswith(state):
            self.connectedState = state + "-prepare"

        if DEBUG:
            print(self.connectedState)

        if self.connectedState.startswith("normal"):
            self.draw_normal_connected()
        elif self.connectedState.startswith("recovery"):
            self.draw_recovery_connected()
        elif self.connectedState.startswith("dfu"):
            self.draw_dfu_connected()
        else:
            self.lastConnectedState = self.connectedState = None
            return False

        self.lastConnectedState = lastConnectedState
        if not self.lastConnectedState:
            self.lastConnectedState = self.connectedState

        self.connected = True

        return True

    realtime_pages = ["home", "systeminfo"]
    def main(self):
        # Start looping through pages
        connectRefreshTick = 0
        while True:
            try:
                if connectRefreshTick > 0.4 and self.handle_connected(): # when looped empty for 0.4sec, we check usb once
                    # when connected refresh everytime
                    need_commit = True
                    connectRefreshTick = 0 # reset to zero after refresh
                elif self.lastPageIndex != self.pageIndex or self.pageIndex in self.realtime_pages:
                    # when not connected, refresh when page switched
                    self.handle_not_connected()
                    need_commit = True
                else:
                    # else we don't refresh
                    need_commit = False

                if need_commit:
                    # Display image
                    painter.commit()
                    time.sleep(0.1)
                    connectRefreshTick += 0.5
                else:
                    connectRefreshTick += 0.01
                    time.sleep(0.01)
            except KeyboardInterrupt:
                break
            except IOError:
                print ("Error")


if __name__ == "__main__":
    box = Ra1nBox()
    box.main()